# -*- coding: utf-8 -*-
"""
Created on Thu Nov 10 21:24:15 2022

@author: Mikes
"""
import numpy
from numpy.fft import *

a = numpy.array([2,3,4,1])
L = fft(a)
print(L)