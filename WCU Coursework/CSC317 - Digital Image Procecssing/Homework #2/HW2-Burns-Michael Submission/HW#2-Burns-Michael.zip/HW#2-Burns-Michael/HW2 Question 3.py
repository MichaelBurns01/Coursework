# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 19:48:31 2022

@author: Mike
"""

import skimage.io as io
import skimage.util.noise as noise
import scipy.ndimage as ndi
from matplotlib import pyplot as plt
#import numpy.ndimage as ndi

image = io.imread(r"C:\Users\Mike\OneDrive - West Chester University of PA\CSC 317 - Digital Image Processing\Original Images\Images\chicken.png") #Reading in image
imgSP = noise.random_noise(image,mode='s&p',amount=0.2) #Applying 20% Salt and Pepper noise to image 
#io.imshow(img_saltpepper_noise) #Displying image

averageFilter = ndi.uniform_filter(imgSP,3) #Denoising salt and pepper image with average filter
#io.imshow(averageFilter) #Displaying image

medianFilter = ndi.median_filter(imgSP,3) #Denoising salt and pepper image with median filter
#io.imshow(averageFilter) #Displaying image

gFilter = ndi.gaussian_filter(imgSP,2,truncate = 1) #Denoising salt and pepper image with gaussian filter
#io.imshow(gFilter) #Displaying image

imageNames = ['S&P','Box/Average','Median','Gaussian'] 
images = [imgSP,averageFilter,medianFilter,gFilter]

for i in range(4):
    plt.subplot(1,4,i+1)
    plt.imshow(images[i])
    plt.title(imageNames[i])
    plt.xticks([]),plt.yticks([])
plt.show()

#LAST PART OF QUESTION !!!!#
#The Median Filter gives us the best result.

