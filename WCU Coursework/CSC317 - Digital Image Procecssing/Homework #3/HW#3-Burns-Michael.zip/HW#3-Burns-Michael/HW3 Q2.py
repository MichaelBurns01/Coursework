# -*- coding: utf-8 -*-
"""
Created on Sun Dec  4 14:21:54 2022

@author: Mike
"""

from skimage.morphology import binary_dilation as bwdilate
import skimage.io as io
from matplotlib import pyplot as plt
import numpy as np
import skimage.util.noise as noise

c=io.imread(r"D:\OneDrive - West Chester University of PA\CSC 317 - Digital Image Processing\Original Images\Images\circles.png").astype('bool')*1
x=np.random.random_sample(c.shape)
c[np.nonzero(x>0.95)]= 0
c[np.nonzero(x<=0.05)] = 1

#io.imshow(c)

gn2 = noise.random_noise(c,mode='s&p',amount=0.2)

#plt.imshow(gn2)

sq=np.ones((3,3))
re=bwdilate(c,sq)
re=np.uint8(re)
plt.imshow(x)
plt.imshow(re)
#f=plt.figure(); f.show(io.imshow(re))