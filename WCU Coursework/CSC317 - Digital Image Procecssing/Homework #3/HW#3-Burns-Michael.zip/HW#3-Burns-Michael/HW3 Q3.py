# -*- coding: utf-8 -*-
"""
Created on Sun Dec  4 15:50:17 2022

@author: Mike
"""

import cv2
import numpy as np
import skimage.io as io
from matplotlib import pyplot as plt

chicken = cv2.imread(r"C:\Users\Mike\OneDrive - West Chester University of PA\CSC 317 - Digital Image Processing\Original Images\Images\chicken.png",0)
#io.imshow(chicken)

sobelx = cv2.Sobel(chicken,cv2.CV_64F,1,0,ksize=5) #Sobel X-filter
sobely = cv2.Sobel(chicken,cv2.CV_64F,0,1,ksize=5) #Sobel Y-filter

plt.subplot(1,3,1),plt.imshow(chicken,cmap='gray') #Plotting chickens image
plt.title('Original'),plt.xticks([]),plt.yticks([]) #Title
plt.subplot(1,3,2),plt.imshow(sobelx,cmap='gray') #Plotting Sobel X image
plt.title('Sobel X'),plt.xticks([]),plt.yticks([]) #Title
plt.subplot(1,3,3),plt.imshow(sobely,cmap='gray') #Plotting Sobel Y image
plt.title('Sobel Y'),plt.xticks([]),plt.yticks([]) #Title


