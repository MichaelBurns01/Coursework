# -*- coding: utf-8 -*-
"""
Created on Wed Oct  5 22:41:13 2022

@author: Mikes
"""

import skimage.io as io
import cv2


image = io.imread(r"C:\Users\Mike\OneDrive - West Chester University of PA\CSC 317 - Digital Image Processing\Original Images\Images\koala_color.png",0) 
io.imshow(image)

#Displaying Blue Channel
blueImage = image.copy()
blueImage[:,:,1] = 0 #Setting GREEN equal to 0  
blueImage[:,:,2] = 0 #Setting RED equal to 0
io.imshow(blueImage)

#Displaying Green Channel
greenImage = image.copy()
greenImage[:,:,0] = 0 #Setting BLUE equal to 0
greenImage[:,:,2] = 0 #Setting RED equal to 0
io.imshow(greenImage)

#Displaying Red Channel
redImage = image.copy()
redImage[:,:,0] = 0 #Setting BLUE equal to 0
redImage[:,:,1] = 0 #Setting GREEN equal to 0io
io.imshow(redImage)

#Splitting channels into Blue, Green and Red
b,g,r = cv2.split(image)

#Merging the channels back to the original
merge = cv2.merge([r,r,r])
io.imshow(merge)

#Keeping only the Red and Green channels on the original image
red_blue = image.copy()
red_blue[:,:,1] = 0 #Setting GREEN channel to 0
io.imshow(red_blue)
