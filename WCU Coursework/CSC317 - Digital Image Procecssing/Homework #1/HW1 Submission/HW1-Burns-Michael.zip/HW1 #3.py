# -*- coding: utf-8 -*-
"""
Created on Thu Sep 29 19:57:34 2022

@author: Mikes
"""
import skimage.exposure as ex
import skimage.io as io
import numpy as np
import cv2 as cv2
from matplotlib import pyplot as plt
import pylab

image = io.imread(r"C:\Users\Mike\OneDrive - West Chester University of PA\CSC 317 - Digital Image Processing\Original Images\Images\chickens.png")
cv2.imwrite('chicken.jpg', image) #Saving chickens.png as chickens.jpg
io.imshow(image) #displaying Chickens image

hist = cv2.calcHist([image],[0],None,[256],[0,256]) #Calculating the Histogram

l = plt.hist(image.ravel(),256,[0,256]); plt.show() #displaying Histogram

ch = ex.equalize_hist(image) #applying the Histogram Equalization

io.imshow(ch) #displaying enhanced image

newHist = cv2.calcHist([ch],[0],None,[256],[0,256]) #Calculating new Histogram

plot = plt.hist(ch.ravel(),256,[0,256]); plt.show() #displaying Histogram
